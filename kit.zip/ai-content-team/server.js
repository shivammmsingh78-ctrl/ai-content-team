/* MISSION CONTROL — dashboard in the same design language as the reference post:
   light blueprint grid, pixel robots, mono labels, handwritten accents.
   npm start -> http://localhost:3000 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = __dirname;
const PORT = process.env.PORT || 3000;
const OUT = path.join(ROOT, 'output');
const today = () => new Date().toISOString().slice(0, 10);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.mp4': 'video/mp4', '.json': 'application/json', '.woff2': 'font/woff2' };

let run = null, lastLines = [];
const sse = new Set();
function feedLines() {
  if (run) return run.lines;
  if (lastLines.length) return lastLines;
  try { return fs.readFileSync(path.join(OUT, today(), 'run.log'), 'utf8').split('\n').filter(Boolean).slice(-120); } catch { return []; }
}
const push = line => { if (run) run.lines.push(line); sse.forEach(r => r.write(`data: ${JSON.stringify(line)}\n\n`)); };

const queuePath = () => path.join(OUT, today(), 'queue.json');
const readQueue = () => { try { return JSON.parse(fs.readFileSync(queuePath(), 'utf8')); } catch { return []; } };
const envPath = () => path.join(ROOT, '.env');
function readEnv() {
  const o = {};
  try { fs.readFileSync(envPath(), 'utf8').split('\n').forEach(l => { const i = l.indexOf('='); if (i > 0) o[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }); } catch {}
  return o;
}
const writeEnv = (k, v) => { const o = readEnv(); o[k] = v; fs.writeFileSync(envPath(), Object.entries(o).map(([a, b]) => a + '=' + b).join('\n') + '\n'); };
const cfg = () => { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8')); } catch { return {}; } };

const COMPOSERS = {
  instagram: 'https://www.instagram.com/create/select/',
  x: 'https://x.com/compose/post',
  linkedin: 'https://www.linkedin.com/feed/',
  'youtube-shorts': 'https://studio.youtube.com/',
  tiktok: 'https://www.tiktok.com/upload',
};
const GUIDES = {
  instagram: 'Meta for Developers (free) -> create app -> Instagram Graph API product -> token. Save as IG_TOKEN.',
  x: 'developer.x.com free tier -> project -> Bearer Token. Save as X_TOKEN.',
  linkedin: 'linkedin.com/developers (free) -> app -> Community Management access. Save as LI_TOKEN.',
  'youtube-shorts': 'Google Cloud free quota -> YouTube Data API v3 -> OAuth client. Save as YT_TOKEN.',
  tiktok: 'developers.tiktok.com -> Content Posting API (review needed). Save as TT_TOKEN.',
};

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const send = (code, body, type = 'application/json') => { res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
  let body = '';
  req.on('data', d => body += d);
  req.on('end', () => {

    if (u.pathname === '/') return send(200, DASHBOARD, 'text/html; charset=utf-8');

    if (u.pathname.startsWith('/assets/')) {
      const f = path.join(ROOT, 'assets', path.basename(u.pathname));
      if (!fs.existsSync(f)) return send(404, 'nope');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
      return fs.createReadStream(f).pipe(res);
    }

    if (u.pathname === '/api/state') {
      const env = readEnv();
      return send(200, JSON.stringify({
        date: today(), running: !!run, niche: cfg().niche || '',
        queue: readQueue(), composers: COMPOSERS, guides: GUIDES,
        voice: cfg().voiceover || 'en-IN-NeerjaExpressiveNeural',
        flags: {
          llm: !!(env.LLM_KEY || process.env.GITHUB_TOKEN),
          tokens: { instagram: !!env.IG_TOKEN, x: !!env.X_TOKEN, linkedin: !!env.LI_TOKEN, 'youtube-shorts': !!env.YT_TOKEN, tiktok: !!env.TT_TOKEN },
        },
        logTail: feedLines().slice(-100),
        stamp: (() => { try { return fs.statSync(queuePath()).mtimeMs | 0; } catch { return 1; } })(),
      }));
    }

    if (u.pathname === '/api/stream') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(':ok\n\n');
      feedLines().slice(-200).forEach(l => res.write(`data: ${JSON.stringify(l)}\n\n`));
      sse.add(res);
      req.on('close', () => sse.delete(res));
      return;
    }

    if (u.pathname === '/api/run' && req.method === 'POST') {
      if (run) return send(200, JSON.stringify({ ok: false }));
      run = { lines: [] };
      const proc = spawn('node', ['team.js', '--count', process.env.COUNT || '5'], { cwd: ROOT });
      let buf = '';
      const on = d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { push(buf.slice(0, i)); buf = buf.slice(i + 1); } };
      proc.stdout.on('data', on); proc.stderr.on('data', on);
      proc.on('exit', code => { push('[manager] run finished (code ' + code + ')'); lastLines = run.lines; run = null; });
      return send(200, JSON.stringify({ ok: true }));
    }

    if (u.pathname === '/api/approve' && req.method === 'POST') {
      const { id } = JSON.parse(body || '{}');
      const q = readQueue();
      q.forEach(x => { if (id == null || x.id === id) x.status = 'approved'; });
      fs.writeFileSync(queuePath(), JSON.stringify(q, null, 2));
      push('[you] approved ' + (id == null ? 'all reels' : 'reel ' + id));
      return send(200, JSON.stringify({ ok: true }));
    }

    if (u.pathname === '/api/save' && req.method === 'POST') {
      const { kind, key, value } = JSON.parse(body || '{}');
      if (kind === 'env') writeEnv(key, value);
      if (kind === 'config') { const c = cfg(); c[key] = value; fs.writeFileSync(path.join(ROOT, 'config.json'), JSON.stringify(c, null, 2)); }
      push('[you] saved ' + key);
      return send(200, JSON.stringify({ ok: true }));
    }

    if (u.pathname === '/api/testllm' && req.method === 'POST') {
      const { key } = JSON.parse(body || '{}');
      if (key) { process.env.LLM_KEY = key; writeEnv('LLM_KEY', key); }
      const { ask } = require('./src/llm.js');
      return ask('Reply with exactly one word.', 'say READY')
        .then(t => send(200, JSON.stringify({ ok: true, reply: t.slice(0, 40) })))
        .catch(e => send(200, JSON.stringify({ ok: false, reply: String(e.message).slice(0, 120) })));
    }

    if (u.pathname.startsWith('/video/') || u.pathname.startsWith('/file/')) {
      const f = path.join(OUT, today(), path.basename(u.pathname));
      if (!fs.existsSync(f)) return send(404, 'nope');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' });
      return fs.createReadStream(f).pipe(res);
    }

    send(404, JSON.stringify({ error: 'not found' }));
  });
});

server.listen(PORT, '0.0.0.0', () => console.log('MISSION CONTROL on http://0.0.0.0:' + PORT));

/* ================= DASHBOARD (post-style design) ================= */
const DASHBOARD = `<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Content Team — Mission Control</title>
<style>
@font-face{font-family:'Inter';src:url('/assets/fonts/Inter-400.woff2') format('woff2');font-weight:400}
@font-face{font-family:'Inter';src:url('/assets/fonts/Inter-700.woff2') format('woff2');font-weight:700}
@font-face{font-family:'Inter';src:url('/assets/fonts/Inter-800.woff2') format('woff2');font-weight:800}
@font-face{font-family:'Inter';src:url('/assets/fonts/Inter-900.woff2') format('woff2');font-weight:900}
@font-face{font-family:'Space Mono';src:url('/assets/fonts/SpaceMono-400.woff2') format('woff2');font-weight:400}
@font-face{font-family:'Space Mono';src:url('/assets/fonts/SpaceMono-700.woff2') format('woff2');font-weight:700}
@font-face{font-family:'Caveat';src:url('/assets/fonts/Caveat-600.woff2') format('woff2');font-weight:600}
*{margin:0;box-sizing:border-box}
body{font-family:Inter,system-ui,Arial,sans-serif;color:#101114;background:#F2F3F7;
 background-image:linear-gradient(rgba(35,48,95,.05) 1.5px,transparent 1.5px),linear-gradient(90deg,rgba(35,48,95,.05) 1.5px,transparent 1.5px);background-size:54px 54px}
.wrap{max-width:1220px;margin:0 auto;padding:26px 24px 80px}
.mono{font-family:'Space Mono',ui-monospace,monospace}
header{display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin-bottom:22px}
.badge{font:700 17px 'Space Mono';color:#2563F0;border:3px solid #2563F0;border-radius:12px;padding:8px 16px;letter-spacing:2px;background:rgba(255,255,255,.6)}
.hc{font:700 16px 'Space Mono';letter-spacing:5px}
.hc .dim{color:#9AA0AA}
.swipe{font:600 26px Caveat,cursive;color:#2563F0}
.spacer{flex:1}
button{cursor:pointer;font:700 13px 'Space Mono';letter-spacing:1.5px;border-radius:12px;padding:12px 20px;border:2px solid #101114;background:#fff;color:#101114;box-shadow:0 6px 16px rgba(20,30,70,.12)}
button:hover{transform:translateY(-1px)}
.go{background:#2563F0;border-color:#2563F0;color:#fff;box-shadow:0 10px 24px rgba(37,99,240,.35)}
.go:disabled{opacity:.55;cursor:wait}
.okb{background:#fff;border-color:#1F7A4D;color:#1F7A4D}
h2{font:700 14px 'Space Mono';letter-spacing:4px;color:#8A8F98;margin-bottom:14px}
.card{background:#FBFBFD;border-radius:18px;box-shadow:0 14px 34px rgba(25,35,70,.10);padding:22px;margin-bottom:20px}
.agents{display:grid;grid-template-columns:repeat(7,1fr);gap:12px;margin-bottom:20px}
@media(max-width:1000px){.agents{grid-template-columns:repeat(4,1fr)}}
@media(max-width:640px){.agents{grid-template-columns:repeat(2,1fr)}}
.ag{background:#fff;border-radius:14px;box-shadow:0 10px 22px rgba(25,35,70,.10);padding:14px 12px;text-align:center;position:relative;border-top:4px solid var(--c)}
.ag svg{width:44px;height:30px}
.ag .nm{font-weight:800;font-size:13px;margin-top:6px}
.ag .dp{font:700 10px 'Space Mono';letter-spacing:2px;color:var(--c)}
.ag .st{font-size:10.5px;color:#9AA0AA;margin-top:4px;min-height:14px}
.ag.work{outline:2px solid var(--c)}
.ag.work .st{color:var(--c);font-weight:700}
.reel{display:flex;gap:16px;align-items:center;background:#fff;border-radius:14px;box-shadow:0 10px 24px rgba(25,35,70,.10);padding:14px;margin-bottom:12px}
.reel img{width:92px;height:163px;object-fit:cover;border-radius:10px;cursor:pointer;box-shadow:0 8px 18px rgba(0,0,0,.25);flex:none}
.rm{flex:1;min-width:0}
.chips span{font:700 10.5px 'Space Mono';letter-spacing:1.5px;border-radius:8px;padding:4px 10px;margin-right:6px}
.cp{color:#fff}.ct{color:#1F7A4D;background:#E5F5EC}.cs{color:#B47708;background:#FBF0DA}.cs.approved{color:#1F7A4D;background:#E5F5EC}
.rm h3{font-size:15px;font-weight:800;margin:7px 0 3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rm p{font-size:12px;color:#6B7078;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rb{display:flex;gap:8px;flex:none;flex-wrap:wrap;justify-content:flex-end}
.rb button{padding:10px 14px;font-size:11.5px}
@media(max-width:800px){.reel{flex-wrap:wrap}.rb{justify-content:flex-start}}
.cols{display:grid;grid-template-columns:1.05fr 1fr;gap:20px}
@media(max-width:900px){.cols{grid-template-columns:1fr}}
.loop .lr{display:flex;align-items:center;gap:12px;background:#fff;border-radius:11px;box-shadow:0 8px 18px rgba(25,35,70,.08);padding:10px 16px;margin:0 auto;max-width:430px}
.loop .lr svg{width:30px;height:21px}
.loop .lr b{font-size:14px}
.loop .lr span{font-size:11.5px;color:#9AA0AA}
.loop .lr.on{outline:2.5px solid var(--c);outline-offset:1px}
.loop .dn{text-align:center;color:#9AA0AA;font-size:14px;padding:3px 0}
.loop .fin{border:2.5px solid #101114;max-width:430px;margin:6px auto 0;border-radius:11px;padding:10px 16px;display:flex;gap:10px;align-items:center;background:#fff}
input,select{font:13px Inter;border:2px solid #E1E4EA;border-radius:10px;padding:9px 12px;background:#fff;flex:1;min-width:110px;color:#101114}
.row{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
.chip{font:700 10px 'Space Mono';letter-spacing:1.5px;border-radius:8px;padding:5px 9px}
.on{color:#1F7A4D;background:#E5F5EC}.off{color:#8A8F98;background:#EEF0F4}
details{margin:4px 0 8px}summary{cursor:pointer;color:#2563F0;font-size:12px;font-weight:700}
.guide{font-size:12px;color:#6B7078;margin:6px 0}
.note{font-size:11.5px;color:#9AA0AA;margin-top:8px}
li{margin:0 0 8px 16px;font-size:12.5px;color:#4A4E55}
#feed{font:11.5px/1.8 'Space Mono';color:#6B7078;max-height:220px;overflow-y:auto;background:#F4F5F8;border-radius:10px;padding:10px 12px}
#feed .ok{color:#1F7A4D}#feed .blu{color:#2563F0}
.modal{position:fixed;inset:0;background:rgba(8,10,14,.86);display:none;align-items:center;justify-content:center;z-index:50;flex-direction:column;gap:14px}
.modal.open{display:flex}
.modal video{height:82vh;max-width:92vw;border-radius:16px;box-shadow:0 30px 80px rgba(0,0,0,.6);background:#000}
.modal .x{position:absolute;top:18px;right:22px;background:#fff;border:none;border-radius:50%;width:44px;height:44px;font-size:18px}
.modal .mt{color:#EDEEF3;font:700 13px 'Space Mono';letter-spacing:2px}
</style></head><body>
<div class="wrap">
<header>
  <span class="badge">MC / 24</span>
  <span class="hc">AI CONTENT TEAM <span class="dim">· MISSION CONTROL</span></span>
  <span class="swipe">subah kholo, approve karo &#8594;</span>
  <div class="spacer"></div>
  <button class="go" id="run">&#9654; RUN: 5 FRESH REELS</button>
  <button class="okb" id="appr">&#10003; APPROVE ALL</button>
</header>

<div class="agents" id="agents"></div>

<div class="card"><h2>TODAY&#8217;S REELS — DEKHO, APPROVE KARO, POST KARO</h2><div id="reels"></div>
<div class="note">Thumbnail ya WATCH pe click karo — reel isi page pe khulegi. Approve ke bina kuch post nahi hota.</div></div>

<div class="cols">
  <div class="card loop"><h2>THE LOOP — PROCESS LIVE</h2><div id="looprows"></div>
    <div class="fin"><span style="width:10px;height:10px;border-radius:50%;background:#101114"></span><b style="font-size:14px">Repeat</b><span style="font-size:11.5px;color:#9AA0AA">&#8212; your only job: approve the output</span></div>
    <details style="margin-top:14px"><summary>raw console</summary><div id="feed" style="margin-top:8px"></div></details>
  </div>
  <div>
    <div class="card"><h2>CONNECT — SAB OPTIONAL, SAB FREE</h2>
      <div class="row"><span class="chip" id="llmchip">BRAIN</span>
        <input id="llmkey" placeholder="Free AI key: Groq gsk_ / Gemini AIza / OpenRouter / GitHub PAT">
        <button id="llmsave">SAVE</button><button id="llmtest">TEST</button></div>
      <div class="note" id="llmnote">Key ke bina chalta hai (offline brain). GitHub pe GitHub Models auto-free.</div>
      <div class="row" style="margin-top:10px"><span class="chip off">VOICE</span>
        <select id="voice">
          <option value="en-IN-NeerjaExpressiveNeural">Hinglish female (Neerja)</option>
          <option value="hi-IN-SwaraNeural">Hindi female (Swara)</option>
          <option value="hi-IN-MadhurNeural">Hindi male (Madhur)</option>
          <option value="en-IN-PrabhatNeural">Indian male (Prabhat)</option>
          <option value="en-US-AriaNeural">US female (Aria)</option>
          <option value="en-US-GuyNeural">US male (Guy)</option>
        </select><button id="voicesave">SAVE</button></div>
      <details><summary>5 platform tokens (optional) — auto-post ke liye</summary><div id="plats" style="margin-top:10px"></div>
      <div class="note">Tokens sirf tumhare .env me save hote hain.</div></details>
    </div>
    <div class="card"><h2>SAFE RAHNE KE 4 RULE</h2><ul>
      <li><b>Sirf publish</b> — auto like/comment/follow/DM kabhi nahi (sabse bada ban-karan).</li>
      <li><b>Har platform alag caption</b> — same cheez har jagah = spam flag.</li>
      <li><b>Times human</b> — &#177;25 min jitter + 2h+ gap system khud rakhta hai.</li>
      <li><b>Roz approve</b> — human-in-the-loop = account safe.</li>
    </ul></div>
  </div>
</div>
</div>

<div class="modal" id="modal">
  <button class="x" onclick="closeM()">&#10005;</button>
  <div class="mt" id="mt"></div>
  <video id="mv" controls playsinline></video>
</div>

<script>
var $=function(s){return document.querySelector(s)};
var COL={research:"#2563F0",hook:"#C4602F",script:"#CE9230",design:"#6C4BDC",analyze:"#2E8468",plan:"#B26055",publish:"#3B7B94",reel:"#2563F0"};
var ROB=[".XXXXXXXXX.",".XBBB.BBBX.","XXXXXXXXXXX",".XXXXXXXXX.","..XXXXXXX..","..XX...XX..","..XX...XX.."];
function robot(c){var r="";for(var y=0;y<ROB.length;y++)for(var x=0;x<ROB[y].length;x++){var ch=ROB[y][x];if(ch===".")continue;var f=ch==="B"?"#15161B":c;r+='<rect x="'+x+'" y="'+y+'" width="1.05" height="1.05" fill="'+f+'"/>';}
 return '<svg viewBox="0 0 11 7" shape-rendering="crispEdges">'+r+"</svg>";}
var AG=[["research","Researcher","RESEARCH"],["hook","Hook Writer","HOOK"],["script","Script Writer","SCRIPT"],["design","Designer","DESIGN"],["reel","Editor","REEL"],["analyze","Analyst","ANALYZE"],["publish","Publisher","PUBLISH"]];
$("#agents").innerHTML=AG.map(function(a){return '<div class="ag" id="ag-'+a[0]+'" style="--c:'+COL[a[0]]+'">'+robot(COL[a[0]])+'<div class="nm">'+a[1]+'</div><div class="dp">'+a[2]+'</div><div class="st">idle</div></div>'}).join("");
var LOOP=[["research","Research","researcher"],["hook","Hook","hook writer"],["script","Script","script writer"],["design","Design","designer"],["analyze","Analyze","analyst"],["plan","Plan","manager"],["publish","Publish","publisher"]];
$("#looprows").innerHTML=LOOP.map(function(l,i){return '<div class="lr" id="lp-'+l[0]+'" style="--c:'+COL[l[0]]+'">'+robot(COL[l[0]])+"<b>"+l[1]+"</b><span>&#8212; "+l[2]+"</span></div>"+(i<LOOP.length-1?'<div class="dn">&#8595;</div>':"")}).join("");
var PC={instagram:"#C13584",x:"#111111",linkedin:"#0A66C2","youtube-shorts":"#FF0000",tiktok:"#111111"};
var S=null;
function state(){fetch("/api/state").then(function(r){return r.json()}).then(function(s){S=s;render();});}
function render(){
  $("#run").disabled=S.running;
  $("#run").innerHTML=S.running?"&#8987; TEAM WORKING...":"&#9654; RUN: 5 FRESH REELS";
  var q=S.queue;
  $("#reels").innerHTML=q.length?q.map(function(r){
    return '<div class="reel">'+
    (r.poster?'<img src="/file/'+r.poster+'?v='+S.stamp+'" onclick="openM('+r.id+')" alt="">':'<div style="width:92px;height:163px;border-radius:10px;background:#EEF0F4;display:flex;align-items:center;justify-content:center;text-align:center;font:700 10px \'Space Mono\';color:#8A8F98;padding:6px">REEL BANI NAHI<br>ffmpeg check karo</div>')+
    '<div class="rm"><div class="chips"><span class="cp" style="background:'+(PC[r.platform]||"#2563F0")+'">'+r.platform.toUpperCase()+'</span><span class="ct">@ '+r.time+'</span><span class="cs '+r.status+'">'+r.status.toUpperCase()+"</span></div>"+
    "<h3>"+r.idea.replace(/</g,"&lt;")+"</h3><p>"+r.caption.replace(/</g,"&lt;")+"</p></div>"+
    '<div class="rb"><button onclick="openM('+r.id+')">&#9654; WATCH</button>'+
    '<button onclick="copyCap('+r.id+')">COPY CAPTION</button>'+
    '<a target="_blank" href="'+(S.composers[r.platform]||"#")+'"><button>OPEN PLATFORM &#8599;</button></a></div></div>';
  }).join(""):'<div class="note">Queue khali hai &#8212; RUN dabao, team ~3 min me 5 fresh reels banayegi.</div>';
  $("#llmchip").className="chip "+(S.flags.llm?"on":"off");$("#llmchip").textContent=S.flags.llm?"BRAIN ON":"BRAIN: OFFLINE";
  $("#voice").value=S.voice;
  $("#plats").innerHTML=Object.keys(S.composers).map(function(p){
    var tk={instagram:"IG_TOKEN",x:"X_TOKEN",linkedin:"LI_TOKEN","youtube-shorts":"YT_TOKEN",tiktok:"TT_TOKEN"}[p];
    return '<div class="row"><span class="chip '+(S.flags.tokens[p]?"on":"off")+'">'+p.toUpperCase()+'</span>'+
    '<input id="tk_'+p+'" placeholder="'+tk+' (optional)"><button onclick="saveTok(\\''+p+'\\',\\''+tk+'\\')">SAVE</button></div>'+
    '<details><summary>free official token kaise le?</summary><div class="guide">'+S.guides[p]+"</div></details>";
  }).join("");
}
window.openM=function(id){var r=S.queue.find(function(x){return x.id===id});if(!r||!r.reel)return;
  $("#mt").textContent=r.platform.toUpperCase()+" @ "+r.time+" — "+r.idea.toUpperCase().slice(0,60);
  var v=$("#mv");v.src="/video/"+r.reel+"?v="+S.stamp;v.muted=true;$("#modal").className="modal open";v.play();};
window.closeM=function(){$("#modal").className="modal";$("#mv").pause();};
window.copyCap=function(id){var r=S.queue.find(function(x){return x.id===id});if(navigator.clipboard)navigator.clipboard.writeText(r.caption+"\\n\\n"+r.hashtags.join(" "));};
window.saveTok=function(p,tk){var v=document.getElementById("tk_"+p).value;if(!v)return;fetch("/api/save",{method:"POST",body:JSON.stringify({kind:"env",key:tk,value:v})}).then(state);};
var STEP={researcher:"research","hook writer":"hook","script writer":"script",designer:"design",editor:"reel",analyst:"analyze",manager:"plan",publisher:"publish"};
function line(t){
  var fe=$("#feed");var d=document.createElement("div");
  if(/reel-\\d\\d\\.mp4|approved|7\\/7/.test(t))d.className="ok";else if(/\\[agent\\]|\\[llm\\]|REEL \\d/.test(t))d.className="blu";
  d.textContent=t;fe.appendChild(d);fe.scrollTop=fe.scrollHeight;
  for(var k in STEP){if(t.indexOf("[agent] "+k)>-1||(k==="editor"&&t.indexOf("[agent] editor")>-1)){
    Object.keys(STEP).forEach(function(o){var el=document.getElementById("lp-"+STEP[o]);if(el)el.className="lr";var a=document.getElementById("ag-"+STEP[o]);if(a){a.className="ag";a.querySelector(".st").textContent="done";}});
    var lp=document.getElementById("lp-"+STEP[k]);if(lp)lp.className="lr on";
    var ag=document.getElementById("ag-"+STEP[k]);if(ag){ag.className="ag work";ag.querySelector(".st").textContent="working...";}
  }}
  if(t.indexOf("[editor] reel-")>-1){var ag2=document.getElementById("ag-reel");if(ag2){ag2.className="ag";ag2.querySelector(".st").textContent="done";}}
}
var es=null;
function stream(){if(es)return;es=new EventSource("/api/stream");es.onmessage=function(e){line(JSON.parse(e.data))};}
$("#run").onclick=function(){fetch("/api/run",{method:"POST"});stream();setTimeout(state,1200);};
$("#appr").onclick=function(){fetch("/api/approve",{method:"POST",body:"{}"}).then(state);};
$("#llmsave").onclick=function(){fetch("/api/save",{method:"POST",body:JSON.stringify({kind:"env",key:"LLM_KEY",value:$("#llmkey").value})}).then(state);};
$("#llmtest").onclick=function(){$("#llmnote").textContent="testing...";fetch("/api/testllm",{method:"POST",body:JSON.stringify({key:$("#llmkey").value})}).then(function(r){return r.json()}).then(function(j){$("#llmnote").textContent=j.ok?"CONNECTED: "+j.reply:"FAIL: "+j.reply;state();});};
$("#voicesave").onclick=function(){fetch("/api/save",{method:"POST",body:JSON.stringify({kind:"config",key:"voiceover",value:$("#voice").value})}).then(state);};
state();stream();setInterval(state,4000);
</script></body></html>`;
