# AI Content Team — Desktop pe chalao

Preview iframe me kuch cheezein (naya tab, autoplay audio) restrict hoti hain. **Apne desktop pe asli browser me** sab kuch 100% chalta hai — WATCH full-screen, sound, sab.

## Ek baar setup (5 min)

1. **Node.js LTS** — nodejs.org se install karo.
2. **ffmpeg** — Windows: gyan.dev/ffmpeg/builds/ (Essentials) → `bin` folder PATH me daalo. Mac: `brew install ffmpeg`. Linux: `sudo apt install ffmpeg`.
3. **edge-tts** — launcher khud install kar dega (`pip install edge-tts`), ya pehle se: `pip install edge-tts`.

## Roz subah

- **Windows:** `RUN-ME.bat` pe double-click.
- **Mac/Linux:** `./run.sh`

Ye 5 fresh reels banayega (~5 min), phir browser me **http://localhost:3000** khol dega.

## Dashboard pe kya karna hai

1. Reels dekho (WATCH pe click — isi page player khulta hai).
2. **✓ APPROVE ALL** dabao (approve ke bina kuch post nahi hota).
3. Har reel ke liye **COPY CAPTION** → **OPEN PLATFORM ↗** → paste → post. Bas.

## Optional upgrades (sab free)

- **Brain key** (Groq/Gemini/OpenRouter/GitHub PAT) — agents aur smart ho jaate hain. Bina key ke bhi chalta hai.
- **Platform tokens** — CONNECT panel me; sirf jab auto-post chahiye ho.
- **Voice** — Hinglish (Neerja) default; Hindi (Swara/Madhur) bhi option hai.

## Folder kya hai

- `team.js` — 7 agents ka run (research → hook → script → design → editor → analyst → publisher)
- `src/formats.js` — tumhare 10 proven reel formats (reel-scripts-2026.html se)
- `src/video.js` — animated reel editor (ffmpeg): gradient motion, kinetic type, transitions, VO + music
- `server.js` — Mission Control dashboard
- `output/<date>/` — aaj ki reels, posters, captions (queue.json)

## Safe rules (yaad rakho)

Sirf publish karo (auto like/comment/follow kabhi nahi) · har platform alag caption · times human (±25 min jitter system khud) · roz approve = account safe.
