/* EMPLOYEE 01's raw sensors — free public APIs, no keys.
   Rotates queries each run so every day brings DIFFERENT raw material. */

async function hnSignals(tags, limit = 15) {
  const out = [];
  for (const tag of (tags && tags.length ? tags : ['AI'])) {
    try {
      const r = await fetch(`https://hn.algolia.com/api/v1/search_by_date?query=${encodeURIComponent(tag)}&tags=story&hitsPerPage=${limit}`);
      if (!r.ok) continue;
      const d = await r.json();
      for (const h of d.hits || []) {
        if ((h.points || 0) >= 3) out.push({ source: 'hn', title: h.title, points: h.points, comments: h.num_comments || 0, url: h.url || `https://news.ycombinator.com/item?id=${h.objectID}` });
      }
    } catch {}
  }
  return out.sort((a, b) => b.points - a.points).slice(0, limit);
}

async function redditSignals(subs, limit = 12) {
  const out = [];
  for (const sub of (subs || []).slice(0, 4)) {
    try {
      const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 12000);
      const r = await fetch(`https://www.reddit.com/r/${sub}/top.json?t=week&limit=8`, {
        headers: { 'User-Agent': 'ai-content-team-research/0.1' }, signal: ctrl.signal });
      clearTimeout(t);
      if (!r.ok) continue;
      const d = await r.json();
      for (const c of d?.data?.children || []) {
        out.push({ source: `r/${sub}`, title: c.data.title, points: c.data.score, comments: c.data.num_comments, url: `https://reddit.com${c.data.permalink}` });
      }
    } catch {}
  }
  return out.sort((a, b) => b.points - a.points).slice(0, limit);
}

/* seed rotates which tags/subs lead, so consecutive runs differ */
async function gather(config, seed = 0) {
  const rot = (a, s) => a.length ? a.map((_, i) => a[(i + s) % a.length]) : a;
  const tags = rot([...(config.hnTags || ['AI']), 'Show HN', 'Ask HN', 'open source', 'startup'], seed);
  const subs = rot([...(config.subreddits || []), 'Entrepreneur', 'growthhacking', 'NewTubers'], seed);
  const [hn, rd] = await Promise.all([hnSignals(tags.slice(0, 3), 15), redditSignals(subs.slice(0, 4), 12)]);
  const signals = [...hn, ...rd];
  console.log(`  [research] signals: ${hn.length} HN + ${rd.length} Reddit (rotation #${seed})`);
  return signals;
}

module.exports = { gather };
