/* Provider chain — every option is $0:
   1. GitHub Models   (free with any GitHub account; GITHUB_TOKEN on Actions works)
   2. Any OpenAI-compatible free key via env: LLM_BASE_URL + LLM_KEY
      e.g. Groq  https://api.groq.com/openai/v1            (free tier)
           Gemini https://generativelanguage.googleapis.com/v1beta/openai (free tier)
           OpenRouter https://openrouter.ai/api/v1         (free models)
           Ollama http://localhost:11434/v1                (local, free)
   3. offline fallback (deterministic templates — pipeline never dies)
*/

const GITHUB_MODELS = [
  'https://models.github.ai/inference',
  'https://models.inference.ai.azure.com',
];

/* paste any free key, we auto-detect the provider:
   gsk_... = Groq · AIza... = Gemini · sk-or-... = OpenRouter · ghp_... = GitHub Models */
function envProvider() {
  const key = process.env.LLM_KEY || '';
  const base = process.env.LLM_BASE_URL || (
    key.startsWith('gsk_') ? 'https://api.groq.com/openai/v1'
    : key.startsWith('AIza') ? 'https://generativelanguage.googleapis.com/v1beta/openai'
    : key.startsWith('sk-or-') ? 'https://openrouter.ai/api/v1'
    : key.startsWith('ghp_') || key.startsWith('github_pat_') ? 'https://models.inference.ai.azure.com'
    : null);
  if (!base) return null;
  return { name: 'key:' + base.replace('https://', '').split('/')[0], base, key };
}

function githubProvider() {
  const token = process.env.GITHUB_TOKEN || process.env.MODELS_TOKEN;
  if (!token) return null;
  return GITHUB_MODELS.map(base => ({ name: 'github-models', base, key: token }));
}

async function chatAt(p, model, system, user, json = true) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 60000);
  try {
    const res = await fetch(p.base.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(p.key ? { Authorization: `Bearer ${p.key}` } : {}),
      },
      body: JSON.stringify({
        model,
        messages: [ { role: 'system', content: system }, { role: 'user', content: user } ],
        temperature: 0.8,
        ...(json ? { response_format: { type: 'json_object' } } : {}),
      }),
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${p.name} ${res.status}: ${(await res.text()).slice(0, 140)}`);
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content;
    if (!text) throw new Error(p.name + ': empty completion');
    return text;
  } finally { clearTimeout(t); }
}

/* ask(system, user) -> raw text. Throws only if EVERY provider fails. */
async function ask(system, user, opts = {}) {
  const model = process.env.LLM_MODEL || 'gpt-4o-mini';
  const providers = [].concat(envProvider() || [], githubProvider() || []);
  const errors = [];
  for (const p of providers) {
    try {
      const out = await chatAt(p, model, system, user);
      console.log(`  [llm] ${p.name} ok`);
      return out;
    } catch (e) { errors.push(String(e.message || e)); }
  }
  if (providers.length === 0) console.log('  [llm] no key found -> offline mode');
  else console.log('  [llm] providers failed:\n   - ' + errors.join('\n   - '));
  throw Object.assign(new Error('NO_LLM'), { errors });
}

/* tolerant JSON extractor */
function parseJSON(text, fallback) {
  try { return JSON.parse(text); } catch {}
  const m = text.match(/[\[{][\s\S]*[\]}]/);
  if (m) { try { return JSON.parse(m[0]); } catch {} }
  return fallback;
}

module.exports = { ask, parseJSON };
