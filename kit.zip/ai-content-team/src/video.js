/* THE EDITOR — animated 9:16 REEL (mp4), 100% free, ffmpeg-native.
   Real motion: drifting color gradients, slide-in kinetic type, staggered line
   reveals, story-progress fill, xfade cuts between scenes, synth music bed,
   voiceover (edge-tts). No puppeteer needed. */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const F = p => path.join(__dirname, '..', 'assets', 'fonts', p);
const HEAD = F('Inter-900.woff2'), MONO = F('SpaceMono-700.woff2'), BODY = F('Inter-700.woff2');
const PALETTE = ['#2563F0', '#7C3AED', '#0D9488', '#E4572E', '#D62976'];

const has = cmd => {
  try { execFileSync(cmd, ['-version'], { stdio: 'pipe' }); return true; }
  catch (e) { return !!((e.stdout && e.stdout.length) || (e.stderr && e.stderr.length)); };
};

function scenesFrom(script) {
  const s = script.slides || [];
  const clean = t => String(t || '').replace(/\s*(hook|say it in|say it)\s*[^.]*\.?$/i, '').trim();
  const scenes = [];
  const sayOf = x => clean(x.say) || clean((x.head || '') + '. ' + (x.body || ''));
  if (s.length) {
    scenes.push({ kind: 'hook', text: clean(s[0].head) || clean(s[0].body), say: sayOf(s[0]) });
    s.slice(1, -1).slice(0, 5).forEach(x => scenes.push({ kind: 'beat', text: clean(x.head), say: sayOf(x) }));
    const last = s[s.length - 1];
    if (s.length > 1) scenes.push({ kind: 'cta', text: clean(last.head) || 'Follow for more', say: sayOf(last) });
  }
  return scenes.filter(x => x.text);
}

const wrap = (text, w) => {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  const lines = [];
  let cur = '';
  for (const wd of words) {
    if ((cur + ' ' + wd).trim().length > w && cur) { lines.push(cur); cur = wd; }
    else cur = (cur + ' ' + wd).trim();
  }
  if (cur) lines.push(cur);
  return lines;
};

function dur(file) {
  const parse = s => { const v = parseFloat(String(s)); return isFinite(v) ? v : 0; };
  try { return parse(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', file], { stdio: 'pipe' })); }
  catch (e) { return parse(e.stdout || ''); }
}

/* one animated scene clip */
function sceneClip(sc, i, n, t, accent, brand, tmp, log) {
  const tf = (name, txt) => { const p = path.join(tmp, name); fs.writeFileSync(p, txt); return p; };
  const hl = wrap(sc.text, 16).slice(0, 4);
  const fsz = hl.length > 3 ? 84 : hl.length > 2 ? 96 : 112;
  const lh = Math.round(fsz * 1.16);
  const y0 = 960 - Math.round((hl.length * lh) / 2);
  const dt = [];
  /* progress segments */
  const segW = Math.floor((1080 - 112 - 10 * (n - 1)) / n);
  for (let j = 0; j < n; j++) {
    const x = 56 + j * (segW + 10);
    dt.push(`drawbox=x=${x}:y=64:w=${segW}:h=8:color=0xFFFFFF@0.18:t=fill`);
    if (j < i) dt.push(`drawbox=x=${x}:y=64:w=${segW}:h=8:color=${accent}:t=fill`);
    if (j === i) dt.push(`drawbox=x=${x}:y=64:w='max(2,min(t/${t.toFixed(2)},1)*${segW})':h=8:color=${accent}:t=fill`);
  }
  /* tag chip slides in from left */
  const tag = sc.kind === 'hook' ? 'WAIT FOR THIS' : sc.kind === 'cta' ? 'YOUR MOVE' : `${i} / ${n - 1}`;
  dt.push(`drawtext=fontfile=${MONO}:textfile=${tf('tag.txt', tag)}:fontsize=30:fontcolor=0x0A0C11:box=1:boxcolor=${accent}:boxborderw=20:x='if(lt(t,0.4),-700+(t/0.4)*756,56)':y=118`);
  dt.push(`drawtext=fontfile=${MONO}:textfile=${tf('brand.txt', '@' + brand.toLowerCase().replace(/\s+/g, ''))}:fontsize=28:fontcolor=0xFFFFFF@0.55:x=w-tw-56:y=130:alpha='min(1,max(0,(t-0.2)/0.4))'`);
  /* headline lines: staggered rise + fade, first line accent */
  hl.forEach((ln, j) => {
    const tj = (0.12 + j * 0.16).toFixed(2);
    const col = j === 0 ? accent : '0xF4F5F8';
    dt.push(`drawtext=fontfile=${HEAD}:textfile=${tf('h' + j + '.txt', ln)}:fontsize=${fsz}:fontcolor=${col}:line_spacing=0:x=60:y='${y0 + j * lh}-((1-min(1,max(0,(t-${tj})/0.34)))*120)':alpha='min(1,max(0,(t-${tj})/0.28))'`);
  });
  /* caption card */
  const cap = wrap(sc.say || sc.text, 34).slice(0, 3);
  dt.push(`drawbox=x=56:y=1560:w=968:h=${90 + cap.length * 58}:color=0xFFFFFF@0.09:t=fill:enable='gte(t,0.35)'`);
  dt.push(`drawtext=fontfile=${MONO}:textfile=${tf('who.txt', 'VOICEOVER')}:fontsize=25:fontcolor=${accent}:x=94:y=1596:alpha='min(1,max(0,(t-0.4)/0.3))'`);
  cap.forEach((ln, j) => {
    dt.push(`drawtext=fontfile=${BODY}:textfile=${tf('c' + j + '.txt', ln)}:fontsize=40:fontcolor=0xD9DBE2:x=94:y=${1650 + j * 58}:alpha='min(1,max(0,(t-0.5)/0.3))'`);
  });
  /* cta pulse */
  if (sc.kind === 'cta') dt.push(`drawbox=x=56:y=1330:w=968:h=6:color=${accent}:t=fill:enable='lt(mod(t,0.9),0.55)'`);
  const vf = `[0:v]fps=30,drawbox=x=0:y=0:w=iw:h=ih:c=0x000000@0.42:t=fill,drawgrid=w=90:h=90:t=2:c=0x8CA0FF@0.07,${dt.join(',')},fade=t=in:st=0:d=0.25,fade=t=out:st=${Math.max(0, t - 0.25).toFixed(2)}:d=0.25,format=yuv420p[v]`;
  const seg = path.join(tmp, `seg${i}.mp4`);
  const args = ['-y', '-f', 'lavfi', '-i', `gradients=s=1080x1920:speed=0.05:seed=${i * 7 + 3}:c0=0x04060B:c1=0x0B1226:c2=${accent}`];
  args.push('-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=mono');
  args.push('-filter_complex', vf, '-map', '[v]', '-map', '1:a', '-t', t.toFixed(2), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-c:a', 'aac', '-b:a', '96k', seg);
  try { execFileSync('ffmpeg', args, { stdio: 'pipe', timeout: 180000 }); return seg; }
  catch (e) { log.push('seg' + i + ':' + String(e.stderr || e.message).slice(-600)); return null; }
}

async function buildReel(script, cfg, outDir, tag = '') {
  const scenes = scenesFrom(script);
  if (!scenes.length) return { mp4: null, note: 'no scenes' };
  const ffmpeg = has('ffmpeg');
  fs.mkdirSync(outDir, { recursive: true });
  const tmp = path.join(outDir, '_reel' + tag); fs.mkdirSync(tmp, { recursive: true });
  const idx = Math.max(0, parseInt(String(tag).replace(/\D/g, ''), 10) - 1);
  const accent = PALETTE[idx % PALETTE.length];
  const brand = cfg.brand || 'yourname';
  const log = [];

  /* 1. voiceover */
  let audio = [];
  if (has('python3')) {
    for (let i = 0; i < scenes.length; i++) {
      const out = path.join(tmp, `v${i}.mp3`);
      try {
        execFileSync('python3', ['-m', 'edge_tts', '--voice', cfg.voiceover || 'en-IN-NeerjaExpressiveNeural', '--rate', '+6%', '--text', scenes[i].say || scenes[i].text, '--write-media', out], { timeout: 60000, stdio: 'pipe' });
        if (fs.existsSync(out)) audio.push(out);
      } catch (e) { log.push('tts:' + String(e.message).slice(0, 60)); break; }
    }
  }
  const voiced = audio.length === scenes.length;

  /* 2. animated scene clips + VO muxed per scene */
  const clips = [];
  for (let i = 0; i < scenes.length; i++) {
    const t = voiced ? Math.min(dur(audio[i]) || 4, 12) + 0.5 : (scenes[i].kind === 'hook' ? 3.4 : 4.2);
    const seg = sceneClip(scenes[i], i, scenes.length, t, accent, brand, tmp, log);
    if (!seg) continue;
    const withVo = path.join(tmp, `sv${i}.mp4`);
    try {
      if (voiced) execFileSync('ffmpeg', ['-y', '-i', seg, '-i', audio[i], '-map', '0:v', '-map', '1:a', '-t', t.toFixed(2), '-c:v', 'copy', '-c:a', 'aac', '-b:a', '112k', withVo], { stdio: 'pipe', timeout: 120000 });
      else fs.renameSync(seg, withVo);
      clips.push({ f: withVo, t });
    } catch (e) { log.push('vo' + i + ':' + String(e.message).slice(0, 60)); clips.push({ f: seg, t }); }
  }
  if (clips.length < 2 || !ffmpeg) { fs.rmSync(tmp, { recursive: true, force: true }); return { mp4: null, note: log.join(';') || 'no ffmpeg' }; }

  /* 3. xfade cuts + acrossfade voice — pairwise passes (low memory) */
  const XD = 0.4;
  const X = ['slideup', 'smoothleft', 'circleopen', 'slideleft', 'fadewhite'];
  let cur = clips[0];
  for (let j = 1; j < clips.length; j++) {
    const out = path.join(tmp, `m${j}.mp4`);
    const off = Math.max(0, cur.t - XD);
    try {
      execFileSync('ffmpeg', ['-y', '-i', cur.f, '-i', clips[j].f, '-filter_complex',
        `[0:v][1:v]xfade=transition=${X[(j - 1) % X.length]}:duration=${XD}:offset=${off.toFixed(2)}[v];[0:a][1:a]acrossfade=d=${XD}[a]`,
        '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-c:a', 'aac', '-b:a', '112k', out],
        { stdio: 'pipe', timeout: 240000 });
      cur = { f: out, t: cur.t + clips[j].t - XD };
    } catch (e) { log.push('xf' + j + ':' + String(e.stderr || e.message).slice(-300)); }
  }
  const bare = cur.f;

  /* 4. synth music bed under voice */
  const D = dur(bare) || 30;
  const mp4 = path.join(outDir, `reel${tag || ''}.mp4`);
  try {
    execFileSync('ffmpeg', ['-y', '-i', bare,
      '-f', 'lavfi', '-i', `sine=f=196:d=${D}`, '-f', 'lavfi', '-i', `sine=f=247:d=${D}`, '-f', 'lavfi', '-i', `sine=f=294:d=${D}`,
      '-filter_complex',
      `[1:a][2:a][3:a]amix=inputs=3,volume=0.04,lowpass=f=900,tremolo=f=0.22:d=0.4[m];[0:a][m]amix=inputs=2:weights='1 0.5':duration=first,alimiter=limit=0.95[a]`,
      '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '112k', '-movflags', '+faststart', mp4],
      { stdio: 'pipe', timeout: 180000 });
  } catch (e) { log.push('music:' + String(e.message).slice(0, 60)); fs.copyFileSync(bare, mp4); }

  fs.rmSync(tmp, { recursive: true, force: true });
  const poster = path.join(outDir, `reel${tag || ''}.jpg`);
  try { execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', mp4, '-ss', '1.1', '-frames:v', '1', '-vf', 'scale=540:-1', poster], { stdio: 'pipe', timeout: 60000 }); } catch {}
  return { mp4, poster: fs.existsSync(poster) ? path.basename(poster) : null, voiced, scenes: scenes.length, duration: dur(mp4), note: log.join(';') };
}

module.exports = { buildReel, scenesFrom };
