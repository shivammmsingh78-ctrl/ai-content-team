/* THE 7 EMPLOYEES — each = system prompt + LLM call + offline fallback.
   Offline fallbacks keep the loop running with $0 and no keys; with a free
   GitHub Models / Groq / Gemini key the same agents write with a real LLM. */

const { ask, parseJSON } = require('./llm.js');

const SYS = (role, extra) =>
  `You are ${role} in a 7-person AI content team. You ONLY answer with valid JSON, no markdown fences. ` +
  `Write original copy (never copy source text). ${extra}`;

async function run(name, system, user, fallback, shape) {
  console.log(`[agent] ${name} working...`);
  try {
    const text = await ask(system, user);
    const data = parseJSON(text, null);
    if (data && shape(data)) return { by: 'llm', [name]: data };
    console.log(`  [agent] ${name}: bad JSON from LLM, using fallback`);
  } catch (e) { /* offline */ }
  return { by: 'offline', [name]: fallback() };
}

/* ---------------- 01 RESEARCHER ---------------- */
function researcher(signals, cfg) {
  const used = (cfg._history || []).slice(-30);
  const sys = SYS('THE RESEARCHER', `Niche: ${cfg.niche}. Audience: ${cfg.audience}. Find viral opportunities. NEVER repeat these used ideas: ${JSON.stringify(used)}`);
  const user = `Headline signals (title, points, comments):\n${JSON.stringify(signals)}\n` +
    `Return JSON: {"trends":[{"name","why"}],"ideas":[{"title","angle","format","score"}],"niches":[".."]}. ` +
    `Give 6 fresh ideas scored 1-10 for a ${cfg.niche} audience. Original angles only, not summaries of the headlines.`;
  const fb = () => {
    const seed = cfg._seed || 0;
    const stop = new Set(['the','a','an','of','for','to','with','on','in','and','or','is','are','it','its','at','by','from','how','why','what','launch','show','ask','new','via']);
    const kw = t => { const w = (t || '').replace(/[^\w\s-]/g, '').split(/\s+/).filter(x => x && !stop.has(x.toLowerCase()) && x.length > 2); return w.slice(0, 2).join(' ') || 'this tool'; };
    const P = [
      k => `What the ${k} launch teaches ${short(cfg.niche)} creators`,
      k => `${k}: the ${short(cfg.niche)} angle nobody is posting`,
      k => `I tried ${k} for 7 days as ${art(short(cfg.niche))} creator`,
      k => `Why ${k} is trending - steal this for ${short(cfg.niche)}`,
      k => `${k} x ${short(cfg.niche)}: the crossover post`,
      k => `3 ${short(cfg.niche)} lessons hiding inside ${k}`,
    ];
    const angles = ['steal-the-lesson', 'contrarian', 'experiment', 'trend-jack', 'crossover', 'listicle'];
    const ideas = [];
    const seen = new Set(used.map(u => u.toLowerCase()));
    /* USER FORMATS FIRST — boss ke diye proven formats, history se dedup */
    const fmts = require('./formats.js').formats;
    const unusedF = fmts.filter(f => !used.some(u => (u || '').toLowerCase().includes(f.title.toLowerCase())));
    if (unusedF.length) {
      const rot = seed % unusedF.length;
      const picks = unusedF.slice(rot).concat(unusedF.slice(0, rot)).slice(0, 6);
      return {
        trends: [{ name: 'user formats', why: 'boss ke diye proven reel formats' }],
        ideas: picks.map((f, i) => ({ title: `#${String(f.n).padStart(2, '0')} ${f.title}`, angle: f.goal, format: 'short-video', score: 10 - i, fid: f.n, trending: signals.slice(0, 3).map(s => s.title) })),
        niches: [cfg.niche],
      };
    }
    signals.forEach((s, i) => {
      const title = P[(i + seed) % P.length](kw(s.title));
      if (!seen.has(title.toLowerCase())) { seen.add(title.toLowerCase()); ideas.push({ title, angle: angles[(i + seed) % 6], format: (i + seed) % 2 ? 'short-video' : 'carousel', score: 9 - (i % 4) }); }
    });
    const ever = [
      `The ${short(cfg.niche)} starter pack: 3 tools, 0 budget`,
      `My ${short(cfg.niche)} posting checklist (steal it)`,
      `${short(cfg.niche)} myths I stopped believing after 10k followers`,
    ];
    ideas.push({ title: ever[seed % ever.length], angle: 'evergreen', format: 'short-video', score: 8 });
    return { trends: [{ name: `${short(cfg.niche)} crossovers`, why: 'launch news + creator angle is under-used' }], ideas: ideas.slice(0, 6), niches: [cfg.niche] };
  };
  return run('researcher', sys, user, fb, d => Array.isArray(d.ideas));
}

/* ---------------- 02 HOOK WRITER ---------------- */
function hookWriter(idea, cfg) {
  const sys = SYS('THE HOOK WRITER', 'You own the first two seconds. Numbers beat promises. Generic dies in the draft.');
  const FREF = idea.fid ? require('./formats.js').formats.find(x => x.n === idea.fid) : null;
  const user = `Idea: ${JSON.stringify(idea)}\nVoice: ${cfg.voice}\n` +
    (FREF ? `PROVEN FORMAT (style reference — copy MAT karna, isi psychology me original likho): ${FREF.title} | psychology: ${FREF.psych} | hook bank examples: ${FREF.hooks.slice(0, 2).join(' / ')}\n` +
      (idea.trending ? `Aaj ke live internet signals: ${idea.trending.join(' · ')} — angle mil sake to mila do.\n` : '') : '') +
    `Return JSON: {"hooks":[10 strings],"best":index,"titles":[3],"thumbnail":"short text"}.`;
  const t = idea.title || 'this idea';
  const top = kwOf(t);
  const fb = () => {
    if (idea.fid) {
      const F = require('./formats.js').formats.find(x => x.n === idea.fid);
      const hs = F.hooks.filter(h => h && !h.startsWith('('));
      const b = (cfg._seed || 0) % hs.length;
      return { hooks: hs, best: b, titles: [idea.title], thumbnail: (hs[b] || '').slice(0, 48) };
    }
    return {
    hooks: [
      `I tested ${top} for 30 days. The numbers:`,
      `Nobody tells beginners this about ${top}:`,
      `The ${top} mistake that quietly costs you followers:`,
      `3 ${top} rules I wish I knew on day 1:`,
      `Your first 1000 followers and ${top}: the truth:`,
      `I studied 50 viral ${top} posts. The pattern:`,
      `Stop doing this with ${top} if you want growth:`,
      `The 2-minute ${top} system that compounds:`,
      `Beginner vs pro with ${top}: the one difference:`,
      `Save this before you write your next post:`,
    ],
      best: t.length % 10,
      titles: [trunc(t, 70), `30 days of ${short(cfg.niche)}, measured`, `The beginner roadmap nobody posts`],
      thumbnail: 'SAVE THIS',
    };
  };
  return run('hookwriter', sys, user, fb, d => Array.isArray(d.hooks));
}

/* ---------------- 03 SCRIPT WRITER ---------------- */
function scriptWriter(idea, hook, cfg) {
  const sys = SYS('THE SCRIPT WRITER', 'Structure: HOOK (first 3s) / VALUE (the core) / PROOF (results) / CTA (the ask). Every word planned.');
  const FREF2 = idea.fid ? require('./formats.js').formats.find(x => x.n === idea.fid) : null;
  const user = `Idea: ${JSON.stringify(idea)}\nChosen hook: ${JSON.stringify(hook)}\nVoice: ${cfg.voice}\nFormat: ${idea.format || 'carousel'}\n` +
    (FREF2 ? `PROVEN FORMAT STRUCTURE (style reference — copy MAT karna): ${FREF2.title} | psychology: ${FREF2.psych} | beats example: ${JSON.stringify(FREF2.scenes.slice(0, 3).map(s => s.v))} | mat karna: ${FREF2.dont}\n` +
      `Isi structure me ORIGINAL Hinglish script likho: har scene me specific number/detail ho, tension ek ho, ending mid-sentence cut ho.\n` : '') +
    `Return JSON: {"format","slides":[{"head","body","say"}],"caption","hashtags":[12],"cta"}. 'say' = voiceover line (Hinglish, bolne layak).`;
  const fb = () => {
    if (idea.fid) {
      const F = require('./formats.js').formats.find(x => x.n === idea.fid);
      const hs = F.hooks.filter(h => h && !h.startsWith('('));
      const hk = ((hook.hooks || [])[hook.best || 0]) || hs[0] || idea.title;
      const spoken = l => String(l || '').replace(/[()]/g, ' ').replace(/\s+/g, ' ').trim();
      const slides = F.scenes.map(s => {
        const say = spoken(s.l) || spoken(s.v);
        return { head: say.split(' ').slice(0, 6).join(' '), body: say, say, vis: s.v };
      });
      return {
        format: 'short-video', slides,
        caption: hk + '\n\n' + F.psych,
        hashtags: ['#reels', '#creator', '#growth', '#contentstrategy', '#viral', '#hooks', '#storytelling', '#aitools', '#buildinpublic', '#shorts', '#learnontiktok', '#marketing'],
        cta: '',
      };
    }
    return ({
    format: idea.format || 'carousel',
    slides: [
      { head: trunc((hook.hooks || [])[hook.best || 0] || idea.title, 60), body: 'the hook — say it in 3 seconds' },
      { head: 'The problem', body: `Most ${short(cfg.niche)} creators guess. Guessing stalls growth.` },
      { head: 'What actually works', body: 'One platform. One format. One promise. For 30 days.' },
      { head: 'Step 1', body: 'Steal structure, not content. Study 10 winners in your niche.' },
      { head: 'Step 2', body: 'Write 10 hooks. Ship the best one. Kill the other nine.' },
      { head: 'Step 3', body: 'One CTA only: follow, save, or reply. Never all three.' },
      { head: 'The proof', body: 'Consistency beats intensity. Same time daily, same promise.' },
      { head: 'Your move', body: `Follow for one practical ${short(cfg.niche)} play, daily.` },
    ],
    caption: `${trunc((hook.hooks || [])[hook.best || 0] || idea.title, 90)}\n\nOne practical play, every day. Save this for your next post.`,
    hashtags: ['#creator', '#growth', '#contentstrategy', '#solopreneur', '#buildinpublic', '#marketing', '#aitools', '#personalbrand', '#shorts', '#reels', '#learnontiktok', '#startup'],
      cta: `Follow for one practical ${short(cfg.niche)} play, daily.`,
    });
  };
  return run('scriptwriter', sys, user, fb, d => Array.isArray(d.slides));
}

/* ---------------- 05 ANALYST ---------------- */
function analyst(metrics, cfg) {
  const sys = SYS('THE ANALYST', 'Turn data into better content. If no data, output a tracking plan.');
  const user = `Metrics (may be empty): ${JSON.stringify(metrics || [])}\nReturn JSON: {"learnings":[".."],"adjustments":[".."],"tracking":["metric to watch"]}.`;
  const fb = () => ({
    learnings: ['No metrics yet — first week is calibration.', 'Hook quality predicts reach more than topic.'],
    adjustments: ['Publish at ' + (cfg.postTimes?.[0] || '18:00') + ' for 7 days before changing anything.'],
    tracking: ['first-hour views', 'save rate', 'follow conversion', 'hook hold rate (3s)'],
  });
  return run('analyst', sys, user, fb, d => Array.isArray(d.tracking));
}

/* ---------------- 07 PUBLISHER ---------------- */
function publisher(pack, cfg) {
  const sys = SYS('THE PUBLISHER', 'On time. Every time. Adapt one master post per platform.');
  const user = `Master pack: ${JSON.stringify(pack)}\nPlatforms: ${cfg.platforms}\nReturn JSON: {"posts":[{"platform","time","text","hashtags":[..],"assets":[..]}],"checklist":[".."]}.`;
  const master = `${pack.caption}\n\n${(pack.hashtags || []).slice(0, 6).join(' ')}`;
  const fb = () => ({
    posts: cfg.platforms.map(p => ({
      platform: p,
      time: cfg.postTimes?.[0] || '18:00',
      text: p === 'x' ? trunc(master, 280) : p === 'linkedin' ? pack.caption + '\n\n' + (pack.hashtags || []).slice(0, 5).join(' ') : master,
      hashtags: (pack.hashtags || []).slice(0, p === 'linkedin' ? 5 : 12),
      assets: pack.assets || [],
    })),
    checklist: ['proofread caption', 'check first slide reads in 2s', 'alt text added', 'link in bio updated'],
  });
  return run('publisher', sys, user, fb, d => Array.isArray(d.posts));
}

/* ---------------- 06 MANAGER (also orchestrates, see team.js) ---------------- */
function manager(summary, cfg) {
  const sys = SYS('THE MANAGER', 'You run the whole company. One plan, no noise.');
  const user = `Today's output: ${JSON.stringify(summary)}\nNote: ${cfg.managerNote}\nReturn JSON: {"verdict","tomorrow":"one priority","status":"one line"}.`;
  const fb = () => ({
    verdict: 'Output approved for review. One post, fully packaged.',
    tomorrow: 'Publish today\'s pack at ' + (cfg.postTimes?.[0] || '18:00') + '; log first-hour numbers for the Analyst.',
    status: '7/7 employees reported. Awaiting your approval.',
  });
  return run('manager', sys, user, fb, d => !!d.verdict);
}

const STOPW = new Set(['the','a','an','of','for','to','with','on','in','and','or','is','are','it','its','at','by','from','how','why','what','launch','show','ask','new','via','this','that']);
const kwOf = t => { const w = (t || '').replace(/[^\w\s-]/g, '').split(/\s+/).filter(x => x && !STOPW.has(x.toLowerCase()) && x.length > 2); return w.slice(0, 2).join(' ') || 'this niche'; };
const trunc = (s, n) => (s || '').length > n ? (s || '').slice(0, n - 1) + '…' : (s || '');
const short = s => { const w = (s || '').split(' ').slice(0, 3); if (w[w.length-1] === 'for' || w[w.length-1] === 'of') w.pop(); return w.join(' ') || (s || ''); };
const art = s => (/^[aeiou]/i.test(s || '') ? 'an ' : 'a ') + s;

module.exports = { researcher, hookWriter, scriptWriter, analyst, publisher, manager };
