/* USER'S 10 REEL FORMATS — source of truth for ideas (from reel-scripts-2026.html).
   Each format: n, goal, dur, title, psych, hooks[], scenes[{t,v,l}], dont. */

module.exports = {
  formats: [
    { n: 1, goal: 'SAVE', dur: '30-45s', title: 'THE RECEIPT DROP',
      psych: 'Dimaag claim ko reject karta hai, proof ko store karta hai — asli number = save button.',
      hooks: [
        'Ye mera bank statement hai. Ab main aapko batata hoon isme kya galat hai.',
        '41,300 followers. 90 din. Screen record on hai, dekh lijiye.',
        'Main aapko wo dikhata hoon jo koi course bechne wala nahi dikhata — apna asli data.',
        'Isme se 3 cheezein kaam aayi. Baaki 11 waste thi. Dono dikha raha hoon.'
      ],
      scenes: [
        { t: '0:00', v: 'Phone screen, analytics graph upar ja raha hai', l: 'Ye 90 din ka data hai. Zero se 41,300. Ab main line by line batata hoon kya hua.' },
        { t: '0:04', v: 'Screen record — actual dashboard scroll', l: 'Pehle 30 din. 400 followers. Main har roz post kar raha tha aur kuch nahi ho raha tha.' },
        { t: '0:11', v: 'Zoom on the spike', l: 'Yahan. Day 34. Ek video ne 2 lakh views kiye. Aur maine wo galti se banaya tha.' },
        { t: '0:18', v: 'Cut to you, plain background', l: 'Wo video 11 second ka tha. Baaki sab 60 second ke. Mujhe samajh aaya ki main zyada bol raha tha.' },
        { t: '0:26', v: 'Back to screen, side by side', l: 'Maine agle 30 videos 15 second ke banaye. Ye raha result. Average views 400 se 19,000.' },
        { t: '0:35', v: 'You, direct to camera', l: 'Aur ek cheez jo bilkul kaam nahi aayi — hashtags. Maine 20 videos bina hashtag ke daale. Koi farak nahi pada.' },
        { t: '0:42', v: 'Final frame, graph', l: 'Bas. Yahi tha.' }
      ],
      dont: 'Screenshot blur karna. Naam, handle, date — sab visible chhodo.' },
    { n: 2, goal: 'COMMENT', dur: '40-60s', title: 'THE 45-SECOND ARGUMENT',
      psych: 'Log disagree karne par type karte hain — comment algorithm ko bolta hai ye discussion hai.',
      hooks: [
        'Consistency overrated hai. Aur main 400 videos banane ke baad ye bol raha hoon.',
        'Aapka niche problem nahi hai. Aapki awaaz boring hai. Koi ye nahi bolega isliye main bol raha hoon.',
        'Main 2 saal se galat advice de raha tha. Aaj wo theek kar raha hoon.',
        'Agar aapko 10,000 followers chahiye toh ye video mat dekhiye. Ye uske baad ke liye hai.'
      ],
      scenes: [
        { t: '0:00', v: 'You, single take, no music', l: 'Consistency overrated hai.' },
        { t: '0:05', v: 'Same frame, no cut', l: 'Aur main jaanta hoon ki ye sunne mein bakwaas lagta hai. Har banda bolta hai daily post karo, algorithm consistency reward karta hai.' },
        { t: '0:13', v: 'Slight lean in', l: 'Aur unki logic sahi bhi hai — jitna post karoge, utna data algorithm ko milega. Ye jhoot nahi hai.' },
        { t: '0:20', v: 'Turn', l: 'Par maine 400 videos banaye. 380 ne kuch nahi kiya. 20 ne sab kiya. Consistency ne mujhe 400 tak pahunchaya — par jo 20 chale, wo isliye chale kyunki unme kuch alag tha.' },
        { t: '0:32', v: 'Specific example', l: 'Mera sabse bada video maine bimaar hote hue banaya tha. Ek take. Ganda lighting. Wo 8 lakh gaya. Uske aage-peeche wale perfect videos 2000 par atke.' },
        { t: '0:44', v: 'The concession', l: 'Ho sakta hai main galat hoon. Agar aap abhi shuru kar rahe ho toh consistency hi sikhaayegi. Main unse baat kar raha hoon jo 1 saal se daily post kar rahe hain aur kuch nahi ho raha.' },
        { t: '0:55', v: 'Abrupt', l: 'Unko volume nahi chahiye. Unko—' }
      ],
      dont: '4 retakes lena. Ek take mein bolo, thoda haklao bhi — wahi proof hai.' },
    { n: 3, goal: 'BOOKMARK', dur: '25-40s', title: 'THE MYTH KILL',
      psych: 'Myth todna chhota dopamine hit hai — log ise bhejte hain taaki wo smart lagein.',
      hooks: [
        'Subah 5 baje utho — ye advice aapke liye nahi hai. Main batata hoon kyun.',
        'Sab kehte hain niche pakdo. Maine 3 saal niche pakda aur wahi meri sabse badi galti thi.',
        '8 glass paani. Kahan se aaya ye number? Kisi ne check hi nahi kiya.',
        'Multitasking exist hi nahi karti. Ye scientifically proven hai aur phir bhi har JD mein likha hota hai.'
      ],
      scenes: [
        { t: '0:00', v: 'Text on screen + you', l: 'Sab kehte hain — subah 5 baje utho. Successful log jaldi uthte hain.' },
        { t: '0:04', v: 'Softer tone', l: 'Aur ye belief kahin se toh aaya hai. Jitne CEO interviews hain, sab 5 AM bolte hain. Toh galat lagta bhi nahi.' },
        { t: '0:09', v: 'Turn — first counter', l: 'Par sleep research kehti hai ki chronotype genetic hota hai. Aapka body clock aapka choice nahi hai — wo DNA mein likha hai.' },
        { t: '0:17', v: 'Second counter', l: 'Aur jo log apne natural chronotype ke against jaate hain, unki cognitive performance girti hai. Jaldi uth rahe ho, par kaam ganda kar rahe ho.' },
        { t: '0:25', v: 'Third — the real reason', l: 'Wo CEOs 5 baje isliye uthte hain kyunki wo 9 baje sote hain. Koi ye hissa nahi batata. Wo jaldi nahi uth rahe — jaldi so rahe hain.' },
        { t: '0:33', v: 'Replacement', l: 'Time mat badlo. Duration fix karo. 7 ghante, consistent time par. Chahe wo 12 se 7 ho.' },
        { t: '0:40', v: 'One-liner', l: '5 AM ek habit nahi hai. Wo ek side effect hai.' }
      ],
      dont: 'Myth ko mazaak mat banao. Main bhi yahi maanta tha — se shuru karo.' },
    { n: 4, goal: 'SHARE', dur: '15-30s', title: 'THE SCALE SHOCK',
      psych: 'Bade number ko time ya distance mein convert karo — shock reflex share karwata hai.',
      hooks: [
        '1 million second = 11 din. 1 billion second = 31 saal. Ab samjhe amiron ka farak?',
        'Agar aap har second ek rupaya gino, ek crore ginne mein 115 din lagenge.',
        'Aapke phone mein Apollo 11 se 100,000 guna zyada computing power hai. Aur aap usse reels dekh rahe ho.',
        'Insaan ki poori recorded history Earth ki umar ka 0.000006% hai.'
      ],
      scenes: [
        { t: '0:00', v: 'Big number, full screen', l: 'Ek million aur ek billion. Sunne mein bas ek shabd ka farak lagta hai.' },
        { t: '0:04', v: 'Visual: clock/calendar', l: 'Ek million second kitna hai? Gyaarah din.' },
        { t: '0:08', v: 'Beat of silence, then', l: 'Ek billion second? Ikkatis saal.' },
        { t: '0:12', v: 'Escalate — visual scale', l: 'Yaani agar aap 1994 mein ginna shuru karte, aaj tak gin rahe hote.' },
        { t: '0:18', v: 'Personal gut punch', l: 'Aur ek trillion? Aap Ice Age mein ginna shuru karte. Insaan ne kheti bhi shuru nahi ki thi.' },
        { t: '0:25', v: 'Final visual, no voice', l: 'Sirf teen numbers screen par. Silence. 3 second.' }
      ],
      dont: 'Number galat mat rakhna. Har number verify karo, source screen par daalo.' },
    { n: 5, goal: 'HOOK', dur: '15-25s', title: 'THE REVERSE TRANSFORMATION',
      psych: 'After pehle dikhao — curiosity gap khulta hai: ye kaise hua.',
      hooks: [
        'Ye kamra 2 ghante pehle aisa tha. Haan.',
        '800 rupaye. Poora kharcha. Ab dikhata hoon pehle kya tha.',
        'Log poochte hain kaise kiya. Theek hai, reverse mein dikhata hoon.',
        'Ye final result hai. Ab main aapko wo dikhaunga jo maine kisi ko nahi dikhaya.'
      ],
      scenes: [
        { t: '0:00', v: 'AFTER — best angle, full impact', l: 'Sirf visual. Do second.' },
        { t: '0:02', v: 'HARD CUT to BEFORE, same angle', l: 'Do ghante pehle.' },
        { t: '0:05', v: 'Process, 6x speed, sound on', l: 'Original sound rakho — sped up sound satisfying hota hai.' },
        { t: '0:14', v: 'One slowdown moment', l: 'Sabse satisfying step ko real speed par 2 second dikhao.' },
        { t: '0:18', v: 'AFTER again — slow pan', l: 'Ab detail dikhao. Viewer ne ise earn kiya hai.' },
        { t: '0:23', v: 'Number overlay', l: '800 rupaye. 2 ghante. Koi tool nahi kharida.' }
      ],
      dont: 'Before aur after ka lighting alag mat rakhna — log cheating pakad lete hain.' },
    { n: 6, goal: 'WATCH TIME', dur: '7-12s', title: 'THE SEAMLESS LOOP',
      psych: 'Viewer ko pata hi nahi chalta ki video repeat hua — retention 400%.',
      hooks: [
        'Loop mein hook words nahi hote — visual hi hook hai.',
        'Ek object mid-motion mein — camera already move kar raha ho.',
        'Kuch girta hua, jo aakhir mein wapas apni jagah aa jaata hai.',
        'Ek transformation jo circular ho — A se B se wapas A.'
      ],
      scenes: [
        { t: '0:00', v: 'ENTRY FRAME — motion mid-way', l: 'Camera already pan kar raha ho. Static start matlab loop dikh jaata hai.' },
        { t: '0:01', v: 'The cycle begins', l: 'Object transform hona shuru — paint mixing, object rotating, liquid pouring.' },
        { t: '0:05', v: 'Peak / midpoint', l: 'Sabse dramatic moment. Yahan viewer decide karta hai rukna hai ya nahi.' },
        { t: '0:08', v: 'Return begins', l: 'Wapas original state ki taraf. Speed same rakho.' },
        { t: '0:10', v: 'EXIT FRAME = ENTRY FRAME', l: 'Exactly same pixel position, same light, same motion direction.' }
      ],
      dont: 'First aur last frame side-by-side check karna mat bhoolna — 2 frame ka mismatch bhi dikhta hai.' },
    { n: 7, goal: 'SHARE', dur: '10-20s', title: 'THE DEADPAN ABSURD',
      psych: 'Absurdity ko koi acknowledge nahi karta — tension build hoti hai, share hi release hai.',
      hooks: [
        'Koi verbal hook nahi — visual absurdity hi hook hai.',
        'Bilkul normal frame se shuru, phir kuch bilkul galat.',
        'Camera react na kare — no zoom, no sound effect.',
        'Characters absurdity ko roz ki baat samjhein.'
      ],
      scenes: [
        { t: '0:00', v: 'Totally normal establishing shot', l: 'Office desk, kitchen, bus stop. Boring. Guard down.' },
        { t: '0:02', v: 'The absurdity enters — no reaction', l: 'Kuch bilkul galat hota hai. Camera bilkul nahi hilta. No music sting.' },
        { t: '0:05', v: 'Someone addresses it — flatly', l: 'Yaar tumne kal bhi yahi kiya tha.' },
        { t: '0:09', v: 'Normal conversation continues', l: 'Absurdity ko background mein chalne do jabki log kuch aur discuss karein.' },
        { t: '0:14', v: 'ESCALATION — second absurd layer', l: 'Ek aur galat cheez. Phir bhi koi react nahi karta. Yahi share button hai.' },
        { t: '0:18', v: 'CUT — no resolution', l: 'Bina explain kiye, bina punchline ke.' }
      ],
      dont: 'Music lagana ya reaction shot daalna. Silence hi ise 10x funny banati hai.' },
    { n: 8, goal: 'COMPLETION', dur: '20-40s', title: 'THE COMPLETE PROCESS',
      psych: 'Adhoora kaam dekhna dimaag ko uncomfortable karta hai — completion rate 80%+.',
      hooks: [
        '1 second final result flash, phir wapas start — visual promise.',
        'Pehla decisive action, hands in frame, macro shot.',
        'Crisp original sound — ye ASMR layer hai.',
        'Ek continuous shot, koi cut nahi.'
      ],
      scenes: [
        { t: '0:00', v: 'Flash the END result — 1 second only', l: 'Viewer ko pata hona chahiye wo kis taraf ja raha hai.' },
        { t: '0:02', v: 'Cut to start — first action', l: 'Hands in frame. Macro. Sound crisp — knife, brush, click.' },
        { t: '0:06', v: 'UNBROKEN MIDDLE', l: 'Ek continuous shot. Speed adjust kar sakte ho, par CUT mat karo.' },
        { t: '0:28', v: 'THE COMPLETION MOMENT — real speed', l: 'Wo exact second jab cheez ban jaati hai. Ise speed up MAT karo. Yahi poora payoff hai.' },
        { t: '0:34', v: 'REST — 3 seconds, silence', l: 'Finished result par ruko. Koi voiceover nahi. Breathing room hi satisfying banata hai.' }
      ],
      dont: 'Music ke neeche original sound mat dabao — process ka sound hi content hai.' },
    { n: 9, goal: 'IMMERSION', dur: '20-35s', title: 'THE COMPLETE POV',
      psych: 'POV mein viewer participant hota hai — mirror neurons fire hote hain.',
      hooks: [
        'Koi setup nahi — seedha moment ke beech mein drop.',
        'Hands frame mein — hands hi POV establish karti hain.',
        'Camera thoda shake kare — perfect stabilization fake lagta hai.',
        'Reaction sirf sound se — face dikhaya toh POV toot gaya.'
      ],
      scenes: [
        { t: '0:00', v: 'Drop into the moment — hands visible', l: 'Koi intro nahi. Viewer seedha beech mein. Hands matlab POV lock.' },
        { t: '0:03', v: 'Anticipation build', l: 'Slow hands. Thodi hesitation. Tension yahin banta hai.' },
        { t: '0:10', v: 'THE ACTION', l: 'Camera thoda hile. Stabilize mat karo. Perfect smoothness POV kill karti hai.' },
        { t: '0:20', v: 'Reaction — sound only', l: 'Saans, hasi, ek chhota oh. Face MAT dikhao.' },
        { t: '0:28', v: 'Rest in the result', l: 'Gaze result par ruke. Slow. Jaise viewer khud dekh raha ho.' }
      ],
      dont: 'Camera ko maathe par mount mat karo. Aankhon ki level par rakho.' },
    { n: 10, goal: 'EMOTIONAL SHARE', dur: '30-50s', title: 'THE 40-SECOND FILM',
      psych: 'Complete arc emotionally satisfy karta hai — satisfied viewer hi share karta hai.',
      hooks: [
        'Ek single strong image — koi dialogue nahi.',
        'Ek khaali kursi. Ek adha likha letter. Ek band darwaza.',
        'Situation 4 second mein saaf ho jaani chahiye — bina bole.',
        'Aakhri frame pehle frame ka echo ho, par meaning badla hua.'
      ],
      scenes: [
        { t: '0:00', v: 'THE IMAGE', l: 'Ek visual jo poori situation bata de. No dialogue. Khaali kursi, do plates, ek untouched.' },
        { t: '0:04', v: 'ESTABLISH THE WANT', l: 'Character kya chahta hai — ek action se dikhao, batao mat. Wo phone uthata hai, rakh deta hai.' },
        { t: '0:12', v: 'THE OBSTACLE', l: 'Sabse lamba hissa. Tension yahin rehti hai. Dikhao, explain mat karo.' },
        { t: '0:25', v: 'THE TURN', l: 'Kuch badalta hai. Decision saaf hona chahiye — jeet ya haar, par clear.' },
        { t: '0:38', v: 'THE LAST IMAGE', l: 'Pehla frame wapas, par ab meaning alag. Same shot, alag feeling. Yahi payoff hai.' }
      ],
      dont: 'Trailer mat banao. Arc band hona chahiye.' }
  ],
  rules: [
    'Pehla shabd hi hook ho — Hi guys / Toh aaj hum kabhi nahi.',
    'Specificity = credibility: numbers, dates, naam.',
    'Ek reel = ek tension.',
    'Mid-sentence cut karo — perfect outro reach kill karta hai.',
    'Verbal CTA hata do — tension chhodo, log khud comment karenge.',
    'Ek galti admit karo — log perfect banda trust nahi karte.'
  ]
};
