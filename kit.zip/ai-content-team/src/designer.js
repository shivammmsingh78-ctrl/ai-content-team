/* EMPLOYEE 04 — THE DESIGNER.
   Turns the script into a swipeable HTML carousel and renders 1080x1350 PNGs
   if a Chrome/Chromium binary exists (GitHub runners ship one; $0). */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const ACCENTS = ['#2563F0', '#C4602F', '#CE9230', '#6C4BDC', '#2E8468', '#B26055', '#3B7B94'];

function findChrome() {
  const pptr = path.join(os.homedir(), '.cache', 'puppeteer');
  let pptrBins = [];
  try {
    if (fs.existsSync(pptr)) {
      pptrBins = fs.readdirSync(pptr).filter(d => d.startsWith('chrome'))
        .flatMap(d => fs.readdirSync(path.join(pptr, d))
          .map(v => path.join(pptr, d, v, 'chrome-linux64', 'chrome')));
    }
  } catch {}
  const cands = [process.env.CHROME_PATH, '/usr/bin/google-chrome', '/usr/bin/chromium',
    '/usr/bin/chromium-browser', '/opt/google/chrome/chrome', ...pptrBins].filter(Boolean);
  for (const c of cands) { try { if (fs.existsSync(c)) return c; } catch {} }
  return null;
}

const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function slideHTML(s, i, total, brand, accent) {
  return `<div class="slide" style="--a:${accent}">
  <header><div class="badge">${String(i + 1).padStart(2, '0')} / ${total}</div>
    <div class="hcenter"><b>${esc(brand.toUpperCase())}</b></div>
    <div class="swipe">swipe &#8594;</div></header>
  <div class="body"><h1>${esc(s.head || '')}</h1><p>${esc(s.body || '')}</p></div>
  <footer><span>${esc(brand.toUpperCase())}</span><span>${String(i + 1).padStart(2, '0')} / ${total}</span></footer>
</div>`;
}

function doc(list, brand) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
  *{margin:0;box-sizing:border-box}html,body{width:1080px;height:1350px;overflow:hidden;background:#222}
  .slide{--a:#2563F0;width:1080px;height:1350px;position:relative;overflow:hidden;
    font-family:'Inter',system-ui,Arial,sans-serif;color:#101114;padding:56px 64px;
    background:radial-gradient(1100px 700px at 50% 26%,#fff 0%,rgba(255,255,255,0) 62%),linear-gradient(#F4F5F8,#EDEEF3);}
  .slide::before{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(35,48,95,.05) 1.5px,transparent 1.5px),linear-gradient(90deg,rgba(35,48,95,.05) 1.5px,transparent 1.5px);background-size:54px 54px}
  header{display:flex;align-items:center;gap:30px;position:relative}
  .badge{font:700 22px 'Space Mono',ui-monospace,monospace;color:#2563F0;border:3px solid #2563F0;border-radius:12px;padding:9px 20px;letter-spacing:2px}
  .hcenter{font:700 19px 'Space Mono',ui-monospace,monospace;letter-spacing:6px}
  .swipe{margin-left:auto;font:600 30px 'Caveat',cursive;color:#2563F0}
  .body{position:relative;margin-top:120px}
  .body h1{font-size:76px;font-weight:900;letter-spacing:-2px;line-height:1.05;color:var(--a)}
  .body p{margin-top:40px;font-size:34px;line-height:1.45;color:#33363C}
  footer{position:absolute;left:64px;right:64px;bottom:44px;display:flex;justify-content:space-between;font:15px 'Space Mono',ui-monospace,monospace;letter-spacing:3px;color:#9AA0AA}
  </style></head><body>` +
    list.map((s, i) => slideHTML(s, i, list.length, brand, ACCENTS[i % ACCENTS.length])).join('') +
    `</body></html>`;
}

async function buildCarousel(script, brand, outDir) {
  const slides = (script.slides || []).slice(0, 10);
  const accent = ACCENTS[0];
  fs.mkdirSync(outDir, { recursive: true });
  const htmlPath = path.join(outDir, 'carousel.html');
  fs.writeFileSync(htmlPath, doc(slides, brand));

  const chrome = findChrome();
  const pngs = [];
  if (chrome) {
    const tmp = path.join(outDir, '_shots');
    fs.mkdirSync(tmp, { recursive: true });
    slides.forEach((s, i) => fs.writeFileSync(path.join(tmp, `s${i}.html`), doc([s], brand)));
    let rendered = false;
    try {
      const core = require('puppeteer-core');
      const browser = await core.launch({
        executablePath: chrome, headless: 'new',
        args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars'],
      });
      const page = await browser.newPage();
      await page.setViewport({ width: 1080, height: 1350, deviceScaleFactor: 1 });
      for (let i = 0; i < slides.length; i++) {
        const out = path.join(outDir, `carousel-${String(i + 1).padStart(2, '0')}.png`);
        await page.goto('file://' + path.join(tmp, `s${i}.html`), { waitUntil: 'load' });
        await page.screenshot({ path: out, clip: { x: 0, y: 0, width: 1080, height: 1350 } });
        pngs.push(out);
      }
      await browser.close();
      rendered = true;
    } catch (e) {
      console.log('  [designer] cdp render failed:', String(e.message).slice(0, 120));
    }
    if (!rendered) for (let i = 0; i < slides.length; i++) {
      const out = path.join(outDir, `carousel-${String(i + 1).padStart(2, '0')}.png`);
      try {
        execFileSync(chrome, ['--headless=new', '--no-sandbox', '--disable-gpu', '--hide-scrollbars',
          '--window-size=1080,1450', '--force-device-scale-factor=1',
          `--screenshot=${out}`, '--virtual-time-budget=3000',
          'file://' + path.join(tmp, `s${i}.html`)], { timeout: 60000, stdio: 'pipe' });
        pngs.push(out);
      } catch (e2) { console.log('  [designer] screenshot failed:', String(e2.message).slice(0, 90)); }
    }
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  return { htmlPath, pngs, accent };
}

module.exports = { buildCarousel, findChrome };
