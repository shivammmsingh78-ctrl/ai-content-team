#!/usr/bin/env bash
# AI Content Team - desktop launcher (mac/linux)
cd "$(dirname "$0")"
echo "== AI CONTENT TEAM =="
command -v node >/dev/null || { echo "node nahi hai: nodejs.org se LTS install karo"; exit 1; }
command -v ffmpeg >/dev/null || { echo "ffmpeg nahi hai: brew install ffmpeg / apt install ffmpeg"; exit 1; }
python3 -m edge_tts --help >/dev/null 2>&1 || pip3 install edge-tts
echo "[1/2] 5 fresh reels (~5 min)..."
node team.js --count 5
echo "[2/2] Dashboard: http://localhost:3000"
( sleep 2; command -v xdg-open >/dev/null && xdg-open http://localhost:3000 || open http://localhost:3000 2>/dev/null ) &
node server.js
