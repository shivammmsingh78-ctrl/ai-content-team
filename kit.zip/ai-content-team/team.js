/* THE MANAGER — runs the whole loop, N reels per day, scheduled across platforms.
   RESEARCH -> HOOK -> SCRIPT -> DESIGN/EDITOR -> ANALYZE -> PLAN -> PUBLISH
   $0: free data APIs + GitHub Models (free tier) + offline fallbacks.
   Usage: node team.js [--count 5] [--niche "..."] */

const fs = require('fs');
const path = require('path');
const { gather } = require('./src/research.js');
const A = require('./src/agents.js');
const { buildReel } = require('./src/video.js');

/* optional .env (keys saved from the dashboard) */
try {
  fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => {
    const i = l.indexOf('=');
    if (i > 0) { const k = l.slice(0, i).trim(); if (k && !process.env[k]) process.env[k] = l.slice(i + 1).trim(); }
  });
} catch {}

const OUT = path.join(__dirname, 'output');
const date = new Date().toISOString().slice(0, 10);
const day = path.join(OUT, date);

function loadConfig() {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
  const i = process.argv.indexOf('--niche');
  if (i > -1 && process.argv[i + 1]) cfg.niche = process.argv[i + 1];
  if (process.env.NICHE) cfg.niche = process.env.NICHE;
  return cfg;
}
const arg = n => { const i = process.argv.indexOf('--' + n); return i > -1 ? process.argv[i + 1] : null; };

/* mirror every log line to output/<date>/run.log so the dashboard feed always has history */
fs.mkdirSync(day, { recursive: true });
fs.writeFileSync(path.join(day, 'run.log'), '');
const _log = console.log;
console.log = (...a) => { _log(...a); try { fs.appendFileSync(path.join(day, 'run.log'), a.join(' ') + '\n'); } catch {} };
const write = (f, data) => {
  const p = path.join(day, f);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, typeof data === 'string' ? data : JSON.stringify(data, null, 2));
  return p;
};

/* human-like slot: base time +- jitter minutes, never identical two days */
function slotTime(base, jitter = 25) {
  const [h, m] = base.split(':').map(Number);
  const j = Math.round((Math.random() * 2 - 1) * jitter);
  const tot = Math.max(6 * 60, Math.min(23 * 60, h * 60 + m + j));
  return `${String(Math.floor(tot / 60)).padStart(2, '0')}:${String(tot % 60).padStart(2, '0')}`;
}

(async () => {
  const cfg = loadConfig();
  const COUNT = Math.min(5, parseInt(arg('count') || process.env.COUNT || '1', 10) || 1);
  fs.mkdirSync(day, { recursive: true });
  console.log(`\n=== AI CONTENT TEAM — daily loop (${date}) · ${COUNT} reel(s) ===`);
  console.log(`niche: ${cfg.niche}\n`);

  /* 01 RESEARCH (rotated signals + history dedup = fresh ideas every run) */
  const seed = (new Date().getUTCDate() + new Date().getUTCHours()) % 7;
  cfg._seed = seed;
  let history = [];
  try { history = JSON.parse(fs.readFileSync(path.join(OUT, 'history.json'), 'utf8')); } catch {}
  cfg._history = history;
  const signals = await gather(cfg, seed);
  write('raw-signals.json', signals);
  const research = (await A.researcher(signals, cfg)).researcher;
  write('01-research.json', research);
  const ideas = (research.ideas || []).sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, COUNT);
  while (ideas.length < COUNT) ideas.push({ title: `${cfg.niche}: mistake #${ideas.length + 1} everyone makes`, angle: 'contrarian', format: 'short-video', score: 7 - ideas.length });

  const slots = cfg.schedule || [{ platform: 'instagram', time: '09:30' }];
  const queue = [];

  for (let k = 0; k < ideas.length; k++) {
    const idea = ideas[k];
    console.log(`\n--- REEL ${k + 1}/${ideas.length}: ${idea.title}`);

    /* 02 HOOK */
    const hooks = (await A.hookWriter(idea, cfg)).hookwriter;
    write(`02-hooks-${k + 1}.json`, { idea, ...hooks });

    /* 03 SCRIPT */
    const script = (await A.scriptWriter(idea, hooks, cfg)).scriptwriter;
    write(`03-script-${k + 1}.json`, script);

    /* 04 EDITOR — the REEL */
    console.log('[agent] editor cutting the reel...');
    const reel = await buildReel(script, cfg, day, `-${String(k + 1).padStart(2, '0')}`);
    console.log(reel.mp4 ? `  [editor] reel-${String(k + 1).padStart(2, '0')}.mp4 (${reel.duration.toFixed(1)}s, vo:${reel.voiced ? 'yes' : 'no'})` : `  [editor] skipped (${reel.note})`);

    /* 07 PUBLISH pack for this slot */
    const slot = slots[k % slots.length];
    const time = slotTime(slot.time, cfg.jitter ?? 25);
    const pub = (await A.publisher({ caption: script.caption, hashtags: script.hashtags, assets: reel.mp4 ? [path.basename(reel.mp4)] : [] }, cfg)).publisher;
    const post = (pub.posts || []).find(p => p.platform === slot.platform) || (pub.posts || [])[0] || { platform: slot.platform, text: script.caption, hashtags: script.hashtags };
    queue.push({
      id: k + 1, idea: idea.title, platform: slot.platform, time,
      reel: reel.mp4 ? path.basename(reel.mp4) : null,
      poster: reel.poster || null,
      caption: post.text || script.caption, hashtags: post.hashtags || script.hashtags || [],
      status: 'pending',
    });
  }

  /* 05 ANALYZE */
  history = history.concat(queue.map(q => q.idea)).slice(-300);
  fs.writeFileSync(path.join(OUT, 'history.json'), JSON.stringify(history, null, 2));
  const metricsFile = path.join(__dirname, 'data', 'metrics.json');
  const metrics = fs.existsSync(metricsFile) ? JSON.parse(fs.readFileSync(metricsFile, 'utf8')) : [];
  const analysis = (await A.analyst(metrics, cfg)).analyst;
  write('05-analysis.json', analysis);

  /* 06 PLAN */
  write('queue.json', queue);
  const calPath = path.join(OUT, 'content-calendar.md');
  const cal = fs.existsSync(calPath) ? fs.readFileSync(calPath, 'utf8') : '# Content calendar\n';
  fs.writeFileSync(calPath, cal + `\n## ${date}\n` + queue.map(q => `- ${q.time} | ${q.platform} | ${q.idea} | NEEDS APPROVAL`).join('\n'));

  const mgmt = (await A.manager({ reels: queue.length, platforms: [...new Set(queue.map(q => q.platform))], first: queue[0]?.time, last: queue[queue.length - 1]?.time }, cfg)).manager;

  write('00-APPROVAL.md',
`# Morning check — ${date} · your only job: verify & approve

**Manager:** ${mgmt.verdict}
**Plan:** ${queue.length} reels across ${[...new Set(queue.map(q => q.platform))].join(', ')} · first ${queue[0]?.time}, last ${queue[queue.length - 1]?.time}
**Status:** ${mgmt.status}

${queue.map(q => `## ${q.id}. [${q.platform} @ ${q.time}] ${q.idea}
- Reel: ${q.reel || '(none)'} · ${q.caption.slice(0, 180)}
- ${q.hashtags.slice(0, 8).join(' ')}
`).join('\n')}
Open the dashboard (npm start) to preview every reel and hit APPROVE ALL.
Nothing posts without your approval. Times are humanized (+-jitter) so the cadence never looks robotic.
`);

  console.log(`\n[manager] ${mgmt.status}`);
  console.log(`[manager] ${queue.length} reels queued. Dashboard: npm start\n`);
})().catch(e => { console.error('LOOP FAILED:', e); process.exit(1); });
