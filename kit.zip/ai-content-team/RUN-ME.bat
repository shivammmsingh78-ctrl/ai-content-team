@echo off
title AI Content Team - Mission Control
echo ============================================
echo   AI CONTENT TEAM - desktop launcher
echo ============================================
where node >nul 2>&1 || ( echo NODE NAHI MILA: nodejs.org se LTS install karke dobara chalao. & pause & exit /b )
where ffmpeg >nul 2>&1 || ( echo FFMPEG NAHI MILA: gyan.dev/ffmpeg/builds/ se essentials le kar PATH me daalo. & pause & exit /b )
python -m edge_tts --help >nul 2>&1 || pip install edge-tts
echo.
echo [1/2] Team kaam kar rahi hai - 5 fresh reels (~5 min)...
node team.js --count 5
echo.
echo [2/2] Dashboard: http://localhost:3000
start "" http://localhost:3000
node server.js
pause
