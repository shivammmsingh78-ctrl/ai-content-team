# Permanent FREE website — 10 minute setup, phir zindagi bhar khud chalta hai

Iske baad **roz subah 6:30 pe agents GitHub ke server pe reels banayenge** (tera data/laptop nahi lagta).
Tu bas phone pe link kholke dekhega: `https://<tera-username>.github.io/<repo-name>/`

## Step 1 — GitHub account (2 min)
1. github.com pe jaao → Sign up (free).
2. Upar right **+** → **New repository**.
3. Naam do: `ai-content-team` → **Public** rakho (Pages free ke liye) → **Create repository**.

## Step 2 — ZIP upload (3 min)
1. Naye repo ke page pe **"uploading an existing file"** link click karo.
2. Is ZIP se extract kiya hua **poora `ai-content-team` folder ka content** drag-drop karo
   (team.js, server.js, src/, tools/, web/, .github/ — sab).
   Note: `.github` folder chhupta hai — file manager me "hidden items" on karke use bhi daalo.
3. Neeche **Commit changes** dabao.

## Step 3 — Actions on (1 min)
1. Repo me **Settings** → left me **Pages** → Source: **GitHub Actions** select karo.
2. **Actions** tab → "Run workflow" (workflow_dispatch) dabao — pehli batch turant banegi.

## Step 4 — Link kholo
~5 min baad: **Settings → Pages** pe jo URL dikhe wahi tumhari website hai.
Roz subah khud update hogi. Data sirf jab lagega jab tum WATCH tap karoge.

## Optional (smart brain, phir bhi $0)
Repo → Settings → Secrets and variables → Actions → New secret:
naam `LLM_KEY`, value tumhari free Groq/Gemini key. Bina key ke bhi chalta hai.

## Agar kabhi khud chalana ho (desktop)
`RUN-ME.bat` (Windows) / `run.sh` (Mac-Linux) — pehle Node + ffmpeg install (DESKTOP-README.md).
