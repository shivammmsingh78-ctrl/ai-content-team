/* web/ static dashboard ke liye data tayyar karta hai (GitHub Pages friendly).
   output/<today>/queue.json + reels/posters -> web/data/ */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const today = new Date().toISOString().slice(0, 10);
const src = path.join(ROOT, 'output', today);
const dst = path.join(ROOT, 'web', 'data');
fs.mkdirSync(dst, { recursive: true });

let queue = [];
try { queue = JSON.parse(fs.readFileSync(path.join(src, 'queue.json'), 'utf8')); } catch {}

for (const f of fs.existsSync(dst) ? fs.readdirSync(dst) : []) {
  if (f.endsWith('.mp4') || f.endsWith('.jpg')) fs.rmSync(path.join(dst, f), { force: true });
}
for (const r of queue) {
  for (const key of ['reel', 'poster']) {
    if (r[key] && fs.existsSync(path.join(src, r[key]))) fs.copyFileSync(path.join(src, r[key]), path.join(dst, r[key]));
  }
}
const state = {
  date: today,
  queue,
  composers: {
    instagram: 'https://www.instagram.com/create/select/',
    x: 'https://x.com/compose/post',
    linkedin: 'https://www.linkedin.com/feed/',
    'youtube-shorts': 'https://studio.youtube.com/',
    tiktok: 'https://www.tiktok.com/upload',
  },
};
fs.writeFileSync(path.join(dst, 'state.json'), JSON.stringify(state));
console.log('[make-web] ' + queue.length + ' reels -> web/data');
