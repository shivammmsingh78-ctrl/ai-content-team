# 🤖 AI CONTENT TEAM — your 7 AI employees, $0 forever

A working recreation of the *"I built an AI content team"* setup as a **real, runnable
multi-agent system** — not pictures of it. Seven agents run the loop every day:

**RESEARCH → HOOK → SCRIPT → DESIGN → ANALYZE → PLAN → PUBLISH → REPEAT**

Your only job is approving the output in `output/<date>/00-APPROVAL.md`.

## 100% free stack

| Piece | What runs it | Cost |
|---|---|---|
| Brains (all 7 agents) | **GitHub Models** (`gpt-4o-mini`, free with any GitHub account — the runner's own `GITHUB_TOKEN` is the key) | $0 |
| Alternative brains | Groq / Gemini / OpenRouter free tiers, or Ollama local — set `LLM_BASE_URL`+`LLM_KEY` | $0 |
| Research data | HN Algolia + Reddit public JSON (no keys) | $0 |
| Design | HTML/CSS carousel + the runner's preinstalled Chrome → 1080×1350 PNGs | $0 |
| **Reel** | THE EDITOR: edge-tts voiceover (free, no key) + ffmpeg → 1080×1920 MP4 | $0 |
| Manager / scheduling | GitHub Actions cron (free tier minutes) | $0 |
| Memory | this repo (`output/`, `content-calendar.md`) | $0 |

No keys left over? The loop still runs in **offline mode** (template brains + real HN
signals) so it can never hard-fail.

## Setup on GitHub (5 min)

1. Create a new GitHub repo and push this folder (`git init && git add -A && git commit && git push`).
2. Done. The `daily-ai-content-team` workflow runs every day at 18:00 UTC.
   - Actions → *daily-ai-content-team* → **Run workflow** to trigger it now (optionally type a niche).
3. Every run: commits `output/<date>/` back to the repo and uploads a `content-pack`
   artifact (approval sheet, hooks, script, carousel HTML + PNGs, per-platform publish pack).

## Your morning routine (Mission Control)

```bash
npm start        # -> http://localhost:3000
```

- **▶ Run today: 5 reels** — agents live kaam karte dikhte hain (cards light up, console streams).
- 5 reels 5 platforms pe, humanized times (±jitter) ke saath queue ho jaati hain.
- Har reel ka video preview dekho, **copy caption** + **open composer** se 30 sec me verify.
- **✓ Approve all** — approval ke bina kuch post nahi hota.
- Right panel: **Anti-detection playbook** — bot-detection se bachne ke rules (implement bhi kiye gaye hain: no engagement automation, unique-per-platform captions, 2h+ gaps, human-in-the-loop).

GitHub pe: workflow roz 18:00 UTC pe loop chala ke results repo me commit kar deta hai;
subah laptop pe `git pull && npm start` — bas verify karo.

## Run locally

```bash
node team.js                     # offline brains + real research signals
node team.js --niche "fitness for dads"
GITHUB_TOKEN=ghp_... node team.js            # GitHub Models brains
LLM_BASE_URL=https://api.groq.com/openai/v1 LLM_KEY=gsk_... node team.js   # Groq
```

Feed the Analyst: drop your post metrics into `data/metrics.json` (any JSON array) and
the next loop learns from it.

## Files

```
team.js                  THE MANAGER — runs the loop end to end
config.json              your niche / platforms / voice / times (edit me)
src/agents.js            employees 01,02,03,05,06,07 (prompts + contracts + fallbacks)
src/designer.js          employee 04 (carousel HTML + PNG rendering)
src/video.js             THE EDITOR (script -> voiced 9:16 reel.mp4; change voice in config.json)
src/research.js          employee 01's sensors (HN + Reddit, keyless)
src/llm.js               provider chain: GitHub Models → env key → offline
.github/workflows/team.yml  the cron + commit-back + artifact
output/<date>/00-APPROVAL.md  your one daily checkpoint
```
